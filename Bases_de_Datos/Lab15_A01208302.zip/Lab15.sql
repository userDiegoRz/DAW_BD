--ALTER TABLE materiales ADD PorcentajeImpuesto NUMERIC(6,2);

--UPDATE materiales SET PorcentajeImpuesto = 2*clave/1000; 

-- Uni�n ----------------------------------------
(select * from entregan where clave=1450) 
union 
(select * from entregan where clave=1300) 

SELECT *
FROM Materiales
----------------------------------------
-- DISTINCT ---------------------------------
SET DATEFORMAT DMY
SELECT Descripcion
FROM Materiales M, Entregan E
WHERE M.Clave = E.Clave
AND FECHA BETWEEN '01/01/2000' AND '31/12/2000'

SET DATEFORMAT DMY
SELECT DISTINCT Descripcion
FROM Materiales M, Entregan E
WHERE M.Clave = E.Clave
AND FECHA BETWEEN '01/01/2000' AND '31/12/2000'

----------------------------------------
-- OPERADORES DE CADENA-----------------


SELECT * FROM Materiales where Descripcion LIKE 'Si%'

SELECT * FROM Materiales where Descripcion LIKE 'Si%'

-- -- -- -- --

SELECT (RFC + ', ' + RazonSocial) as Nombre FROM Proveedores; 

DECLARE @foo varchar(40); 
DECLARE @bar varchar(40); 
SET @foo = '�Que resultado'; 
SET @bar = ' ���??? ' 
SET @foo += ' obtienes?'; 
PRINT @foo + @bar; 

----------------------------------------
-- OPERADORES L�GICOS ------------------

SELECT Clave,RFC,Numero,Fecha,Cantidad 
FROM Entregan 
WHERE Numero Between 5000 and 5010; 

SELECT RFC,Cantidad, Fecha,Numero 
FROM [Entregan] 
WHERE [Numero] Between 5000 and 5010 AND 
Exists ( SELECT [RFC] 
FROM [Proveedores] 
WHERE RazonSocial LIKE 'La%' and [Entregan].[RFC] = [Proveedores].[RFC] ) 

-- -- -- --
SELECT TOP 2 * FROM Proyectos 

SELECT TOP Numero FROM Proyectos 
SELECT TOP 1 Numero FROM Proyectos 


----------------------------------------
-- CREAR UNA VISTA ---------------------

CREATE VIEW VistaUno AS 
SELECT Numero, Cantidad
FROM Entregan E
WHERE E.Clave = 1000

SELECT * FROM VistaUno


----------------------------------------
-- CONSULTAS ---------------------

--1 -> Los materiales (clave y descripci�n) entregados al proyecto "M�xico sin ti no estamos completos".

SELECT M.Clave, M.Descripcion
FROM Entregan E, Materiales M
WHERE E.RFC IN (SELECT RFC FROM Proyectos WHERE Denominacion = 'M�xico sin ti no estamos completos')

--2 -> Los materiales (clave y descripci�n) que han sido proporcionados por el proveedor "Acme tools". 

SELECT M.Clave, M.Descripcion
FROM Entregan E, Materiales M
WHERE E.Numero IN (SELECT Numero FROM Proveedores WHERE RazonSocial = 'Acme tools')

--3 -> El RFC de los proveedores que durante el 2000 entregaron en promedio cuando menos 300 materiales. 

SELECT DISTINCT P.RFC 
FROM Proveedores P, Entregan E
WHERE E.RFC = P.RFC
AND E.Fecha IN (SELECT Fecha FROM Entregan WHERE Cantidad > 300)

--4 -> El Total entregado por cada material en el a�o 2000.
 
SET DATEFORMAT DMY
SELECT M.Descripcion,SUM(E.Cantidad)as 'Total'
FROM Entregan E, Materiales M
WHERE E.Clave = M.Clave 
AND E.Fecha BETWEEN '01/01/2000' AND '31/12/2000'
GROUP BY M.Descripcion

--5 -> La Clave del material m�s vendido durante el 2001. (se recomienda usar una vista intermedia para su soluci�n) 

CREATE VIEW Ventas AS
SELECT E.Clave, SUM(E.Cantidad) as 'Total'
FROM Entregan E, Materiales M
WHERE E.Fecha BETWEEN '01/01/2001' AND '31/12/2001'
AND E.Clave = M.Clave
GROUP BY E.Clave

SELECT TOP 1 Clave
FROM Ventas
ORDER BY Total DESC

--6 -> Productos que contienen el patr�n 'ub' en su nombre. 

SELECT Descripcion 
FROM Materiales
WHERE Descripcion LIKE '%[ub]%'

--7 -> Denominaci�n y suma del total a pagar para todos los proyectos. 

SELECT P.Denominacion, SUM(M.Costo * E.Cantidad) as 'Total'
FROM Proyectos P, Entregan E, Materiales M
WHERE P.Numero = E.Numero
AND M.Clave = E.Clave 
GROUP BY P.Denominacion

--8 -> Denominaci�n, RFC y RazonSocial de los proveedores que se suministran materiales al proyecto Televisa en acci�n que no se encuentran apoyando al proyecto Educando en Coahuila. 

SELECT Y.Denominacion, P.RFC, P.RazonSocial
FROM Proveedores P, Proyectos Y, Entregan E
WHERE E.Numero NOT IN (SELECT E.Numero FROM Entregan E, Proyectos P WHERE P.Denominacion = 'Educando en Coahuila')
AND Y.Denominacion = 'Televisa en acci�n'
AND Y.Numero = E.Numero
AND P.RFC = E.RFC

--10 -> Costo de los materiales y los Materiales que son entregados al proyecto Televisa en acci�n cuyos proveedores tambi�n suministran materiales al proyecto Educando en Coahuila. 

SELECT M.Costo, M.Descripcion
FROM Proveedores P, Proyectos Y, Entregan E, Materiales M
WHERE E.Numero IN (SELECT E.Numero FROM Entregan E, Proyectos P WHERE P.Denominacion = 'Educando en Coahuila')
AND Y.Denominacion = 'Televisa en acci�n'
AND Y.Numero = E.Numero
AND P.RFC = E.RFC
AND M.Clave = E.Clave


