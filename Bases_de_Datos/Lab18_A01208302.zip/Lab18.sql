SELECT SUM(Cantidad) as 'Cantidades', SUM(Costo) as 'Importe'
FROM Entregan E, Materiales M
WHERE E.Clave = M.Clave 
AND E.fecha >= 1997-01-01
AND E.fecha <= 1997-12-31


SELECT RazonSocial, COUNT(Numero) as 'Entregas', SUM(Costo) as 'Importe'
FROM Proveedores P, Entregan E, Materiales M
WHERE P.RFC = E.RFC
AND E.Clave = M.Clave
GROUP BY RazonSocial

SELECT E.Clave, Descripcion, SUM(Cantidad) as 'Cantidad Total', MIN(Cantidad), MAX(Cantidad), SUM(Costo)
        FROM Materiales M, Entregan E
        WHERE M.Clave = E.Clave
		GROUP BY E.Clave,Descripcion
        HAVING AVG(Cantidad) > 400
        

SELECT RazonSocial, E.Clave, Descripcion, AVG(Cantidad) as 'Promedio' 
        FROM Materiales M, Entregan E, Proveedores P
        WHERE E.Clave = M.Clave
        AND P.RFC = E.RFC
		GROUP BY RazonSocial,E.Clave,Descripcion
        HAVING AVG(Cantidad) < 500;

SELECT E.Clave, Descripcion
    FROM Materiales M, Entregan E
    WHERE M.Clave = E.Clave
    AND Cantidad = 0


SELECT DISTINCT M.Descripcion 
    FROM Materiales M, Entregan E
    WHERE E.Numero NOT IN (SELECT Numero FROM Proyectos WHERE Denominacion = 'CIT Yucatan')
    AND M.Clave = E.Clave

SELECT P.RazonSocial, AVG(Cantidad) as 'PromEntregas'
    FROM Proveedores P, Entregan E
    WHERE P.RFC = E.RFC
	GROUP BY P.RazonSocial
	HAVING AVG(Cantidad) > (SELECT AVG(Cantidad) as 'Promedio' FROM Entregan WHERE RFC = 'AAAA800101')


SELECT Cantidad FROM Entregan

SELECT * From Entregan
WHERE RFC =
        



Select * from Materiales

SELECT * from Entregan


SELECT RazonSocial, E.RFC
FROM Proveedores Prov, Entregan E, Proyectos Proy
WHERE Prov.RFC = E.RFC
AND E.Numero = Proy.Numero
AND Proy.Denominacion = 'Infonavit Durango'
AND E.Fecha < '2000-12-31' 
AND E.Fecha > '2000-01-01'
GROUP BY RazonSocial, E.RFC
HAVING SUM(Cantidad) > (    
SELECT SUM(Cantidad) as Promedio2001
FROM Proveedores Prov, Entregan E, Proyectos Proy
WHERE Prov.RFC = E.RFC
AND E.Numero = Proy.Numero
AND Proy.Denominacion = 'Infonavit Durango'
AND E.Fecha < '2001-12-31'
AND E.Fecha > '2001-01-01'
 ) 
