BULK INSERT a1208302.a1208302.[Materiales]
   FROM 'e:\wwwroot\a1208302\materiales.csv'
   WITH
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

BULK INSERT a1208302.a1208302.[Proveedores]
   FROM 'e:\wwwroot\a1208302\proveedores.csv'
   WITH
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

BULK INSERT a1208302.a1208302.[Proyectos]
   FROM 'e:\wwwroot\a1208302\proyectos.csv'
   WITH
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

BULK INSERT a1208302.a1208302.[Entregan]
   FROM 'e:\wwwroot\a1208302\entregan.csv'
   WITH
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

	  sp_help Materiales


	  select * from a1208302.Entregan;